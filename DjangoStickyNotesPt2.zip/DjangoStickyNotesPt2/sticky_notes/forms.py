"""Forms for the Sticky Notes application."""
from django import forms
from .models import Note


class NoteForm(forms.ModelForm):
    """Form for creating and updating sticky notes."""
    class Meta:
        """Meta class for NoteForm."""
        model = Note
        fields = ['title', 'content']
