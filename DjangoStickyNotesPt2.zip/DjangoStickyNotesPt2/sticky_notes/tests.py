"""Unit tests for the Note model in the sticky_notes app."""
from django.test import TestCase
from django.urls import reverse
from .models import Note

class NoteModelTest(TestCase):
    def setUp(self):
        # Create a Note object for testing
        Note.objects.create(title='Test Note', content='This is a test note.')

    def test_note_has_title(self):
        # Test that a Note object has the expected title
        note = Note.objects.get(id=1)
        self.assertEqual(note.title, 'Test Note')

    def test_note_has_content(self):
        # Test that a Note object has the expected content
        note = Note.objects.get(id=1)
        self.assertEqual(note.content, 'This is a test note.')

class NoteViewTest(TestCase):
    def setUp(self):
        # Create a Note object for testing views
        Note.objects.create(title='Test Note', content='This is a test note.')

    def test_note_list_view(self):
        # Test the main list view (Home page)
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')

    def test_note_detail_view(self):
        # Test the detail view for a specific note
        note = Note.objects.get(id=1)
        # Note: Replace 'note_detail' with your actual URL name from urls.py
        response = self.client.get(reverse('update_note', args=[str(note.id)]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'This is a test note.')
