"""Unit tests for the Note model in the sticky_notes app."""
from django.test import TestCase
from django.urls import reverse
from .models import Note


class NoteModelTest(TestCase):
    """Tests for the Note model."""
    def setUp(self):
        # Create a Note object for testing
        Note.objects.create(title='Test Note', content='This is a test note.')

    def test_note_has_title(self):
        """Test that a Note object has the expected title."""
        note = Note.objects.get(id=1)
        self.assertEqual(note.title, 'Test Note')

    def test_note_has_content(self):
        """Test that a Note object has the expected content."""
        note = Note.objects.get(id=1)
        self.assertEqual(note.content, 'This is a test note.')


class NoteViewTest(TestCase):
    """Tests for the views in the sticky_notes app."""
    def setUp(self):
        # Create a Note object for testing views
        Note.objects.create(title='Test Note', content='This is a test note.')

    def test_note_list_view(self):
        """Test the main list view (Home page) for notes."""
        response = self.client.get(reverse('home'))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'Test Note')

    def test_note_creation_view(self):
        """Test that a new note can be created
        via the home view POST request."""
        # We simulate a user filling out the form on the home page
        response = self.client.post(reverse('home'), {
            'title': 'Test Creation Title',
            'content': 'Test Creation Content'
        })
        # After a successful POST, Django usually redirects
        self.assertEqual(response.status_code, 302)
        # Verify the note actually exists in the database
        self.assertTrue(Note.objects.filter(title='Test Creation Title').exists())

    def test_note_update_view(self):
        """Test that an existing note can be edited and saved."""
        note = Note.objects.get(id=1)
        response = self.client.post(reverse('update_note', args=[note.id]), {
            'title': 'Updated Title',
            'content': 'Updated Content'
        })
        self.assertEqual(response.status_code, 302)
        # Pull the note from the DB again to see if it changed
        note.refresh_from_db()
        self.assertEqual(note.title, 'Updated Title')

    def test_note_delete_view(self):
        """Test that a note is successfully removed from the database."""
        note = Note.objects.get(id=1)
        # Hit the delete URL
        response = self.client.post(reverse('delete_note', args=[note.id]))
        self.assertEqual(response.status_code, 302)
        # Verify it no longer exists
        self.assertFalse(Note.objects.filter(id=note.id).exists())
