"""Views for the Sticky Notes application."""
from django.shortcuts import render, redirect, get_object_or_404
from .models import Note
from .forms import NoteForm


def home(request):
    """View function for the home page."""
    if request.method == 'POST':
        form = NoteForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = NoteForm()


# Fetching notes to display
    notes = Note.objects.all()
    return render(request, 'home.html', {'notes': notes, 'form': form})


def update_note(request, pk):
    """View function to update an existing note."""
    note = get_object_or_404(Note, pk=pk)
    if request.method == "POST":
        form = NoteForm(request.POST, instance=note)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = NoteForm(instance=note)
    return render(request, 'update_note.html', {'form': form})


def delete_note(request, pk):
    """View function to delete a note."""
    note = get_object_or_404(Note, pk=pk)
    if request.method == "POST":
        note.delete()
        return redirect('home')
    return render(request, 'delete_note.html', {'note': note})
